import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';

const StressQuestionnaire = () => {
  const [stressors, setStressors] = useState('');
  const [copingMethod, setCopingMethod] = useState('');
  const [recommendations, setRecommendations] = useState('');

//   const handleSubmit = () => {
//     // Here you would typically send the data to a backend API
//     // For this example, we'll just set some mock recommendations
//     setRecommendations(`Based on your input, we recommend:
//     1. Continue with ${copingMethod}
//     2. Try to address your stressor: ${stressors}
//     3. Consider speaking with a professional about stress management`);
//   };

const handleSubmit=()=>{
    
}

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold mb-4">Stress Management Questionnaire</h1>
      <p className="mb-6">Answer the following questions to assess your stress level and receive personalized recommendations.</p>
      
      <div className="mb-4">
        <Label htmlFor="stressors">What is causing you stress?</Label>
        <Input
          id="stressors"
          placeholder="Enter your stressors"
          value={stressors}
          onChange={(e) => setStressors(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <Label>How do you usually cope with stress?</Label>
        <RadioGroup value={copingMethod} onValueChange={setCopingMethod}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="Exercise" id="exercise" />
            <Label htmlFor="exercise">Exercise</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="Meditation" id="meditation" />
            <Label htmlFor="meditation">Meditation</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="Talking to a friend" id="talking" />
            <Label htmlFor="talking">Talking to a friend</Label>
          </div>
        </RadioGroup>
      </div>

      <Button onClick={handleSubmit}>Get Recommendations</Button>
      <Button onClick={handleSubmit}>Take test</Button>

      {recommendations && (
        <div className="mt-6 p-4 bg-gray-100 rounded">
          <h2 className="font-semibold mb-2">Recommendations:</h2>
          <p>{recommendations}</p>
        </div>
      )}
    </div>
  );
};

export default StressQuestionnaire;