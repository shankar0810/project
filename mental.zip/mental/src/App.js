import './App.css';
import PHQ9 from './PHQ9';
 
function App() {
  



  return (
    <div className="App">
       <PHQ9 />
    </div>
  );
}

export default App;
