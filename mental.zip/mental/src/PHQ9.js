import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const PHQ9 = () => {
  const questions = [
    "Little interest or pleasure in doing things?",
    "Feeling down, depressed, or hopeless?",
    "Trouble falling or staying asleep, or sleeping too much?",
    "Feeling tired or having little energy?",
    "Poor appetite or overeating?",
    "Feeling bad about yourself — or that you are a failure or have let yourself or your family down?",
    "Trouble concentrating on things, such as reading the newspaper or watching television?",
    "Moving or speaking so slowly that other people could have noticed? Or the opposite — being so fidgety or restless that you have been moving around a lot more than usual?",
    "Thoughts that you would be better off dead or of hurting yourself in some way?",
  ];

  const [responses, setResponses] = useState(Array(9).fill(null)); // Radio buttons are blank initially
  const [severity, setSeverity] = useState(null); // State to store severity result
  const [showModal, setShowModal] = useState(false); // State to control modal visibility

  const handleChange = (index, value) => {
    const newResponses = [...responses];
    newResponses[index] = parseInt(value);
    setResponses(newResponses);
  };

  const handleSubmit = async () => {
    try {
      const response = await fetch('http://localhost:9090/api/phq9/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ responses }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setSeverity(data.severity); // Store the severity in state
      setShowModal(true); // Show the modal
    } catch (error) {
      console.error("Error submitting the form", error);
    }
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">PHQ-9 Questionnaire</h1>
      {questions.map((question, index) => (
        <div key={index} className="mb-4">
          <p>{index + 1}. {question}</p>
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name={`question-${index}`}
              value="0"
              checked={responses[index] === 0}
              onChange={() => handleChange(index, 0)}
            />
            <label className="form-check-label">Not at all</label>
          </div>
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name={`question-${index}`}
              value="1"
              checked={responses[index] === 1}
              onChange={() => handleChange(index, 1)}
            />
            <label className="form-check-label">Several days</label>
          </div>
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name={`question-${index}`}
              value="2"
              checked={responses[index] === 2}
              onChange={() => handleChange(index, 2)}
            />
            <label className="form-check-label">More than half the days</label>
          </div>
          <div className="form-check form-check-inline">
            <input
              className="form-check-input"
              type="radio"
              name={`question-${index}`}
              value="3"
              checked={responses[index] === 3}
              onChange={() => handleChange(index, 3)}
            />
            <label className="form-check-label">Nearly every day</label>
          </div>
        </div>
      ))}
      <button className="btn btn-primary btn-block" onClick={handleSubmit}>Submit</button>

      {/* Bootstrap Modal */}
      {showModal && (
        <div className="modal show d-block" tabIndex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">PHQ-9 Result</h5>
                <button type="button" className="close" aria-label="Close" onClick={handleCloseModal}>
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <p>Your depression severity is: {severity}</p>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" onClick={handleCloseModal}>Close</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PHQ9;
